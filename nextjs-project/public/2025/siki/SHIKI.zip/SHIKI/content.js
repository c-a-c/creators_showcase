window.addEventListener('load', function () {
    const FILTER_CHARS = ["\n", " ", "　"]; // 無視する文字
    let SEASON = "now";
    let NUMBER_OF_PARTICLES = 10;  // パーティクルの数

    // パーティクルの横方向への速度
    let PARTICLE_VX_MAX = 0.05;
    let PARTICLE_VX_MIN = -0.05;

    // パーティクルの縦方向への速度
    let PARTICLE_VY_MAX = -0.1;
    let PARTICLE_VY_MIN = -0.01;

    // パーティクルのサイズ
    let PARTICLE_SIZE = 10;

    // パーティクルの描画時間
    let PARTICLE_TIME_MIN = 300;
    let PARTICLE_TIME_MAX = 500;

    // パーティクルの重力
    let GRAVITY = 0.005;

    class Texture {
        constructor(paths) {
            this.list = [];
            paths.forEach(path => {
                const img = new Image();
                img.src = chrome.runtime.getURL(path);
                this.list.push(img);
            })
        }

        getTexture(index) {
            if (index < 0 || index >= this.list.length) {
                throw new Error("Index out of range");
            }
            return this.list[index];
        }
    }

    class Setting {
        constructor(PC, delete_particle_event) {
            this.default_setting = {
                SEASON: "now",
                NUMBER_OF_PARTICLES: 10,

                PARTICLE_VX_MAX: 0.05,
                PARTICLE_VX_MIN: -0.05,

                PARTICLE_VY_MAX: -0.1,
                PARTICLE_VY_MIN: -0.01,

                PARTICLE_SIZE: 10,

                PARTICLE_TIME_MIN: 300,
                PARTICLE_TIME_MAX: 500,

                GRAVITY: 0.005,
            }

            this.setting = {}

            this.filter_url = [];

            // ストレージから設定を取得する
            chrome.storage.local.get(["shiki_user_particle_setting"], (res) => {
                this.setting = res.shiki_user_particle_setting || this.default_setting;
                this.applySetting();
            })

            // 設定を更新する
            chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
                if (message.type === "UPDATE_SETTING") {
                    this.applySetting();
                    sendResponse({ status: "success" });
                }
            })
        }

        applySetting() {
            // 設定を適用する
            chrome.storage.local.get(["shiki_user_particle_setting"], (res) => {
                this.setting = res.shiki_user_particle_setting || this.default_setting;

                SEASON = this.setting.SEASON;
                NUMBER_OF_PARTICLES = this.setting.NUMBER_OF_PARTICLES;
                PARTICLE_VX_MAX = this.setting.PARTICLE_VX_MAX;
                PARTICLE_VX_MIN = this.setting.PARTICLE_VX_MIN;
                PARTICLE_VY_MAX = this.setting.PARTICLE_VY_MAX;
                PARTICLE_VY_MIN = this.setting.PARTICLE_VY_MIN;
                PARTICLE_SIZE = this.setting.PARTICLE_SIZE;
                PARTICLE_TIME_MIN = this.setting.PARTICLE_TIME_MIN;
                PARTICLE_TIME_MAX = this.setting.PARTICLE_TIME_MAX;
                GRAVITY = this.setting.GRAVITY;
            })

            chrome.storage.local.get(["url_filter"], (result) => {
                this.filter_url = result.url_filter || [];
                this.filter();
            })
        }

        is_block_url() {
            const current_url = window.location.href;
            return this.filter_url.some(url => {
                if (url === "*") return true; // すべてのURLをブロックする
                const prefix = url.split("*")[0];
                const matched = current_url.startsWith(prefix);
                return matched;
            });
        }

        filter() {
            chrome.storage.local.get(["url_filter"], (result) => {
                this.filter_url = result.url_filter || [];
                if (this.is_block_url()) {
                    // URLフィルターに一致した場合、パーティクルを削除する
                    PC.exit();
                    delete_particle_event.exit();
                } else {
                    PC.init();
                    delete_particle_event.init();
                }
            });
        }
    }

    class ParticleCanvas {
        constructor() {
            this.init();
            this.exiting = true;
        }

        init() {
            if (this.exiting) {
                this.canvas = document.createElement("canvas");
                this.canvas.imageSmoothingEnabled = false;
                this.canvas.style.imageRendering = "pixelated"; // ピクセル化を有効にする
                this.ctx = this.canvas.getContext("2d");


                this.particles = [];

                this.setCanvasSize();
                this.setCanvasPosition();

                this.canvas.style.position = "fixed";
                this.canvas.style.zIndex = "9999";
                this.canvas.style.pointerEvents = "none";

                document.body.appendChild(this.canvas);
                this.preScroll = [window.scrollX, window.scrollY];

                window.addEventListener("scroll", () => {
                    this.setCanvasPosition()    // キャンバスの位置を更新
                    this.setParticlePosition();    // パーティクルの位置を更新
                });
                window.addEventListener("resize", () => this.setCanvasSize());

                this.exiting = false;

                this.draw();
            }

        }

        draw() {
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            this.particles.forEach(p => {
                p.update_position();
                p.draw(this.canvas);


                // アニメーション時間が最大値を超えたら削除
                if (p.animation_time > p.max_time) {
                    this.particles.splice(this.particles.indexOf(p), 1);
                }
            });



            requestAnimationFrame(() => this.draw());
        }

        generateParticles(x, y) {
            for (let i = 0; i < NUMBER_OF_PARTICLES; i++) {
                this.particles.push(
                    new Particle(this.ctx, x, y)
                )
            }
        }

        setCanvasPosition = () => {
            this.canvas.style.left = `0px`;
            this.canvas.style.top = `0px`;
        }

        setCanvasSize = () => {
            this.canvas.width = document.documentElement.clientWidth;
            this.canvas.height = document.documentElement.clientHeight;

            this.canvas.style.width = `${this.canvas.width}px`;
            this.canvas.style.height = `${this.canvas.height}px`;
        }

        setParticlePosition = () => {
            this.particles.forEach(p => {
                p.x -= window.scrollX - this.preScroll[0];
                p.y -= window.scrollY - this.preScroll[1];
            });
            this.preScroll = [window.scrollX, window.scrollY];
        }

        exit() {
            this.canvas.remove();
            this.particles = [];

            this.exiting = true;
        }
    }

    class Particle {
        constructor(ctx, x, y) {
            this.ctx = ctx;

            this.size = PARTICLE_SIZE;

            this.x = x - this.size / 2;
            this.y = y - this.size / 2;
            this.vx = this.Random(PARTICLE_VX_MIN, PARTICLE_VX_MAX);
            this.vy = this.Random(PARTICLE_VY_MIN, PARTICLE_VY_MAX);
            this.y -= this.vy;

            this.texture = this.get_season_texture();

            this.animation_time = 0;    // 現在のアニメーション時間(UNIX秒)
            this.pre_animation_time = 0;    // 前回のアニメーション時間(UNIX秒)
            this.max_time = this.Random(PARTICLE_TIME_MIN, PARTICLE_TIME_MAX);

            this.angle = 0;
            this.opacity = 1;
        }

        draw(canvas) {
            const ctx = this.ctx;

            ctx.save();
            ctx.translate(this.x + this.size / 2, this.y + this.size / 2);
            ctx.rotate(this.angle);

            ctx.globalAlpha = this.opacity;
            ctx.drawImage(this.texture, -this.size / 2, -this.size / 2, this.size, this.size);

            ctx.restore();

            ctx.globalAlpha = 1;
        }

        get_season_texture() {
            switch (SEASON) {
                case "spring":
                    return textures.getTexture(0); // 春のテクスチャ
                case "summer":
                    return textures.getTexture(1); // 夏のテクスチャ
                case "autumn":
                    return textures.getTexture(2); // 秋のテクスチャ
                case "winter":
                    return textures.getTexture(3); // 冬のテクスチャ
                default:
                    return this.get_season_texture_by_month(); // 現在の月に基づくテクスチャ
            }
        }
        get_season_texture_by_month() {
            const month = new Date().getMonth() + 1;

            if (month >= 3 && month <= 5) {
                return textures.getTexture(0); // 春のテクスチャ
            } else if (month >= 6 && month <= 8) {
                return textures.getTexture(1); // 夏のテクスチャ
            }
            else if (month >= 9 && month <= 11) {
                return textures.getTexture(2); // 秋のテクスチャ
            }
            else {
                return textures.getTexture(3); // 冬のテクスチャ
            }
        }

        update_position() {
            const current_time = new Date().getTime();
            let elapsed_time = current_time - this.pre_animation_time;

            // 前回のアニメーション時間が0の場合、経過時間を0にする
            if (this.pre_animation_time === 0) elapsed_time = 0;
            this.animation_time += elapsed_time;


            this.x += this.vx * elapsed_time;
            this.y += this.vy * elapsed_time;

            this.vy += GRAVITY;

            this.angle = Math.atan2(this.vy, this.vx);

            this.opacity = 1 - (this.animation_time / this.max_time);
            if (this.opacity < 0) this.opacity = 0;

            this.pre_animation_time = new Date().getTime();
        }

        Random(min, max) {
            return Math.random() * (max - min) + min;
        }
    }

    class DeleteParticleEvent {
        constructor(PC) {
            this.PC = PC;
            this.init();
        }
        init() {
            this.checkAllInputs();

        }
        checkAllInputs() {
            this.DeleteListener();
            requestAnimationFrame(() => this.checkAllInputs());
        }

        DeleteListener() {
            this.inputs = document.querySelectorAll("input:not([type]),input[type=search], input[type=text], textarea");
            if (this.inputs.length === 0) return;
            this.inputs.forEach(input => {
                if (input.getAttribute("delete-particle-event")) return;
                input.setAttribute("delete-particle-event", "true");
                let pre_value = input.value;

                input.addEventListener("input", () => { pre_value = input.value; });

                input.addEventListener("keydown", (e) => {
                    if (e.key === "Backspace" || e.key === "Delete") {
                        if (this.isContentDeleted(input, pre_value, e.key)) {
                            const offset = (e.key === "Backspace") ? -1 : 0;
                            const caretRect = this.getCaretRect(input, offset);

                            PC.generateParticles(caretRect.x, caretRect.y + caretRect.h / 2);
                        }
                    }
                })

                input.addEventListener("cut", () => {
                    const cutRect = this.getCaretRect(input);

                    PC.generateParticles(cutRect.x, cutRect.y + cutRect.h / 2);
                });
            });
        };

        getCaretRect(input, offset = 0) {
            let caretPos = input.selectionStart + offset;
            if (caretPos < 0) caretPos = 0;
            const selectionRect = this.getSelectionRect(input, caretPos);
            return selectionRect;
        }

        getSelectionRect(input, start) {
            const inputRect = input.getBoundingClientRect();
            const computedStyle = window.getComputedStyle(input);

            // ダミー要素作成
            const dummy = document.createElement('div');
            for (const prop of computedStyle) {
                dummy.style[prop] = computedStyle.getPropertyValue(prop);
            }

            Object.assign(dummy.style, {
                position: "absolute",
                left: `${inputRect.left + window.scrollX}px`,
                top: `${inputRect.top + window.scrollY}px`,
                visibility: "hidden",
                whiteSpace: "pre-wrap",
                wordWrap: "break-word",
                width: `${input.offsetWidth}px`,
                height: `${input.offsetHeight}px`
            });

            dummy.scrollTop = input.scrollTop;
            dummy.textContent = input.value.substring(0, start);

            let selectedText = input.value.substring(start, start + 1);

            // spanの位置がキャレットの座標
            const span = document.createElement('span');
            span.textContent = selectedText || " ";
            dummy.appendChild(span);

            document.body.appendChild(dummy);
            const spanRect = span.getBoundingClientRect();
            document.body.removeChild(dummy);

            return {
                x: spanRect.left - input.scrollLeft,
                y: spanRect.top - input.scrollTop,
                w: spanRect.width,
                h: spanRect.height,
            }
        }

        isContentDeleted(element, pre_value, key) {
            const deletedContent = this.getDeletedContent(element, pre_value, key);

            let fillteredContent = deletedContent;
            let fillteredPrev = pre_value;
            FILTER_CHARS.forEach(char => {
                fillteredContent = fillteredContent.replaceAll(char, "");
                fillteredPrev = fillteredPrev.replaceAll(char, "");
            });

            // 前回文字が残っており、今文字がない場合はtrue
            if (fillteredContent.length === 0 && fillteredPrev.length > 0) return true;

            return fillteredContent.length > 0;
        }

        getDeletedContent(element, pre_value, key) {
            const start = element.selectionStart;
            const end = element.selectionEnd;

            if (key === 'Backspace' && start === end) {
                return pre_value.substring(start - 1, start);
            } else if (key === 'Delete' && start === end) {
                return pre_value.substring(start, start + 1);
            } else {
                return pre_value.substring(start, end);
            }
        }

        exit() {
            this.inputs.forEach(input => {
                input.removeEventListener("input", () => { });
                input.removeEventListener("keydown", () => { });
                input.removeEventListener("cut", () => { });
                input.removeAttribute("delete-particle-event");
            });
        }
    }

    // ここからメイン

    const textures = new Texture([
        "images/spring.png",
        "images/summer.png",
        "images/fall.png",
        "images/winter.png"
    ]);


    const PC = new ParticleCanvas();

    const delete_particle_event = new DeleteParticleEvent(PC);

    const setting = new Setting(PC, delete_particle_event);
})