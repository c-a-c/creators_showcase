chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
        case "UPDATE_SETTING_PARTICLE":
            chrome.storage.local.set({ shiki_user_particle_setting: msg.value });
            break;
        
        case "UPDATE_SETTING_FILTER":
            chrome.storage.local.set({ url_filter: msg.value });
            break;

        default:
            break;
    }

    sendResponse({ status: "success" });

    // すべてのタブにメッセージを送信
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
            chrome.tabs.sendMessage(tab.id, {
                type: "UPDATE_SETTING",
            }).catch((err) => {
                // console.error(`Error sending message to tab ${tab.id}: ${err}`);
            });
        });
    });
});