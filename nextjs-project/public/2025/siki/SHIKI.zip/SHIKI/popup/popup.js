let setting = {};
const default_setting = {
  NUMBER_OF_PARTICLES: 10,

  PARTICLE_VX_MAX: 0.05,
  PARTICLE_VX_MIN: -0.05,

  PARTICLE_VY_MAX: -0.1,
  PARTICLE_VY_MIN: -0.01,

  PARTICLE_SIZE: 10,

  PARTICLE_TIME_MIN: 300,
  PARTICLE_TIME_MAX: 500,

  GRAVITY: 0.005,
}

document.body.style.width = window.screen.width / 4 + "px"

const element = {
  "particleCount": document.getElementById("particleCount"),
  "particleVxMax": document.getElementById("particle_vx_max"),
  "particleVxMin": document.getElementById("particle_vx_min"),
  "particleVyMax": document.getElementById("particle_vy_max"),
  "particleVyMin": document.getElementById("particle_vy_min"),
  "particleSize": document.getElementById("particleSize"),
  "particleTimeMin": document.getElementById("particle_time_min"),
  "particleTimeMax": document.getElementById("particle_time_max"), 
  "gravity": document.getElementById("gravity"),
  "resetBtn": document.getElementById("resetBtn"),
  "saveBtn": document.getElementById("saveBtn"),
}


chrome.storage.local.get(["shiki_user_setting"], (res) => {
  setting = res.shiki_user_setting || default_setting;

  UpdateInputValue();
  Log(`Current setting: ${JSON.stringify(setting)}`)
})


element.saveBtn.addEventListener('click', () => {
  setting.NUMBER_OF_PARTICLES = parseInt(element.particleCount.value) || setting.NUMBER_OF_PARTICLES;

  const vx_max_input =  parseFloat(element.particleVxMax.value || setting.PARTICLE_VX_MAX);
  const vx_min_input = parseFloat(element.particleVxMin.value || setting.PARTICLE_VX_MIN);
  const [vx_min, vx_max] = MinMax(vx_max_input, vx_min_input);
  setting.PARTICLE_VX_MAX = vx_max;
  setting.PARTICLE_VX_MIN = vx_min;

  const vy_max_input = parseFloat(element.particleVyMax.value || setting.PARTICLE_VY_MAX);
  const vy_min_input = parseFloat(element.particleVyMin.value || setting.PARTICLE_VY_MIN);
  const [vy_min, vy_max] = MinMax(vy_max_input, vy_min_input);
  setting.PARTICLE_VY_MAX = vy_max;
  setting.PARTICLE_VY_MIN = vy_min;

  setting.PARTICLE_SIZE = parseFloat(element.particleSize.value) || setting.PARTICLE_SIZE;

  const time_min_input = parseInt(element.particleTimeMin.value) || setting.PARTICLE_TIME_MIN;
  const time_max_input = parseInt(element.particleTimeMax.value) || setting.PARTICLE_TIME_MAX;
  const [time_min, time_max] = MinMax(time_max_input, time_min_input);
  setting.PARTICLE_TIME_MIN = time_min;
  setting.PARTICLE_TIME_MAX = time_max;

  setting.GRAVITY = parseFloat(element.gravity.value) || setting.GRAVITY;

  UpdateInputValue();
  Log(`Setting saved: ${JSON.stringify(setting)}`)

  chrome.runtime.sendMessage({
    type: "UPDATE_SETTING",
    value: setting,
  }, (response) => {
    if (response.status === "success") {
      Log("Settings updated successfully");
    } else {
      Log("Failed to update settings");
    }
  })
});

element.resetBtn.addEventListener('click', () => {
  ResetSetting();
})

function Log(message) {
  const p = document.createElement("p");
  p.textContent = message;
  document.body.appendChild(p);
}

function MinMax(value1, value2) {
  return [Math.min(value1, value2), Math.max(value1, value2)];
}

function UpdateInputValue() {
  element.particleCount.value = setting.NUMBER_OF_PARTICLES;
  element.particleVxMax.value = setting.PARTICLE_VX_MAX;
  element.particleVxMin.value = setting.PARTICLE_VX_MIN;
  element.particleVyMax.value = setting.PARTICLE_VY_MAX;
  element.particleVyMin.value = setting.PARTICLE_VY_MIN;
  element.particleSize.value = setting.PARTICLE_SIZE;
  element.particleTimeMin.value = setting.PARTICLE_TIME_MIN;
  element.particleTimeMax.value = setting.PARTICLE_TIME_MAX;
  element.gravity.value = setting.GRAVITY;
}

function ResetSetting() {
  setting = default_setting;
  UpdateInputValue();
}