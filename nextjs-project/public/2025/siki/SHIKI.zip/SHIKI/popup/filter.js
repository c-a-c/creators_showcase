let url_filter = []

chrome.storage.local.get(["url_filter"], (result) => {
    url_filter = result.url_filter || [];
})

document.getElementById("filter_url").addEventListener("input", (e) => {
    const value = e.target.value;
    const urls = value.split("\n")

    const valid_urls = urls.filter(url => {
        if (url === "*") return true;
        const u = url.trim();
        if (!u) return false;
        try {
            new URL(u);
            return true;
        } catch {
            return false;
        }
    })

    chrome.runtime.sendMessage({
        type: "UPDATE_SETTING_FILTER",
        value: valid_urls
    })
})

chrome.storage.local.get(["url_filter"], (result) => {
    document.getElementById("filter_url").value = result.url_filter.join("\n") ?? "";
})