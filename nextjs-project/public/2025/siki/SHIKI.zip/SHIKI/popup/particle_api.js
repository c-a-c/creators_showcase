const default_setting = {
    SEASON: "now",
    NUMBER_OF_PARTICLES: 10,

    PARTICLE_VX_MAX: 0.05,
    PARTICLE_VX_MIN: -0.05,

    PARTICLE_VY_MAX: -0.01,
    PARTICLE_VY_MIN: -0.1,

    PARTICLE_SIZE: 10,

    PARTICLE_TIME_MIN: 300,
    PARTICLE_TIME_MAX: 500,

    GRAVITY: 0.005,
}


function getSetting(callback) {
    chrome.storage.local.get(["shiki_user_particle_setting"], (res) => {
        callback(res.shiki_user_particle_setting || default_setting);
    })
}

function setAllSetting(setting) {
    chrome.runtime.sendMessage({
        type: "UPDATE_SETTING_PARTICLE",
        value: setting
    }, (response) => {
        if (response.status !== "success") {
            console.error("Failed to save setting");
        }
    })
}

const elem = {
    "season": document.getElementById("particle_season"),
    "amount": document.getElementById("particle_amount"),
    "size": document.getElementById("particle_size"),
    "gravity": document.getElementById("particle_gravity"),
    "vx_max": document.getElementById("particle_vx_max"),
    "vx_min": document.getElementById("particle_vx_min"),
    "vy_max": document.getElementById("particle_vy_max"),
    "vy_min": document.getElementById("particle_vy_min"),
    "time_min": document.getElementById("particle_time_min"),
    "time_max": document.getElementById("particle_time_max"),
}

function saveSetting(set_value = true) {
    const vx_max = Math.max(
        parseFloat(elem.vx_max.value || default_setting.PARTICLE_VX_MAX),
        parseFloat(elem.vx_min.value || default_setting.PARTICLE_VX_MIN)
    )
    const vx_min = Math.min(
        parseFloat(elem.vx_max.value || default_setting.PARTICLE_VX_MAX),
        parseFloat(elem.vx_min.value || default_setting.PARTICLE_VX_MIN)
    )
    const vy_max = Math.max(
        parseFloat(elem.vy_max.value || default_setting.PARTICLE_VY_MAX),
        parseFloat(elem.vy_min.value || default_setting.PARTICLE_VY_MIN)
    )
    const vy_min = Math.min(
        parseFloat(elem.vy_max.value || default_setting.PARTICLE_VY_MAX),
        parseFloat(elem.vy_min.value || default_setting.PARTICLE_VY_MIN)
    )
    const time_max = Math.max(
        parseFloat(elem.time_max.value * 1000 ?? default_setting.PARTICLE_TIME_MAX),
        parseFloat(elem.time_min.value * 1000 ?? default_setting.PARTICLE_TIME_MIN)
    )
    const time_min = Math.min(
        parseFloat(elem.time_max.value * 1000 ?? default_setting.PARTICLE_TIME_MAX),
        parseFloat(elem.time_min.value * 1000 ?? default_setting.PARTICLE_TIME_MIN)
    )
    const setting = {
        SEASON: elem.season.value || default_setting.SEASON,
        NUMBER_OF_PARTICLES: parseInt(
            (elem.amount.value || default_setting.NUMBER_OF_PARTICLES)
        ),
        PARTICLE_SIZE: parseInt(
            (elem.size.value || default_setting.PARTICLE_SIZE)
        ),
        GRAVITY: parseFloat(
            (elem.gravity.value * 0.005 ?? default_setting.GRAVITY)
        ),
        PARTICLE_VX_MAX: vx_max,
        PARTICLE_VX_MIN: vx_min,
        PARTICLE_VY_MAX: vy_max,
        PARTICLE_VY_MIN: vy_min,
        PARTICLE_TIME_MIN: time_min,
        PARTICLE_TIME_MAX: time_max,
    }

    setAllSetting(setting);
    if (set_value) setValueInput(setting);
}

function resetSetting() {
    setAllSetting(default_setting);
    setValueInput(default_setting);
}

function setValueInput(setting) {
    let i;
    switch (setting.SEASON) {
        case "now":
            i = 0;
            break;
        case "spring":
            i = 1;
            break;
        case "summer":
            i = 2;
            break;
        case "autumn":
            i = 3;
            break;
        case "winter":
            i = 4;
            break;
    }
    elem.season.options[i].selected = true;
    elem.amount.value = setting.NUMBER_OF_PARTICLES;
    elem.size.value = setting.PARTICLE_SIZE;
    elem.gravity.value = setting.GRAVITY / 0.005;
    elem.vx_max.value = setting.PARTICLE_VX_MAX;
    elem.vx_min.value = setting.PARTICLE_VX_MIN;
    elem.vy_max.value = setting.PARTICLE_VY_MAX;
    elem.vy_min.value = setting.PARTICLE_VY_MIN;
    elem.time_max.value = setting.PARTICLE_TIME_MAX / 1000;
    elem.time_min.value = setting.PARTICLE_TIME_MIN / 1000;
}

window.addEventListener("load", () => {
    document.getElementById("particle_setting_reset").addEventListener("click", () => {
        resetSetting();
    });

    const setting = getSetting(
        (setting) => {
            setValueInput(setting);
        }
    );

    // それぞれの項目の入力からフォーカス外れたら保存
    Object.keys(elem).forEach((key) => {
        elem[key].addEventListener("input", () => saveSetting(false))
        elem[key].addEventListener("focusout", () => saveSetting())
    })
})
