const main = document.querySelector("main");

function resize_window() {
    const width = Math.floor(window.screen.width / 4);
    
    document.body.style.width = width + 'px';
    document.body.style.height = "fit-content";
}

window.addEventListener("load", () => resize_window());
window.addEventListener("resize", () => resize_window());