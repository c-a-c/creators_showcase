window.addEventListener("load", () => {
    // // generalボタン
    // const general_btn = document.getElementById("tab_general");
    // const general_page = document.getElementById("general_page");
    
    // フィルターボタン
    const filter_btn = document.getElementById("tab_filter");
    const filter_page = document.getElementById("filter_page");
    
    // パーティクルボタン
    const particle_btn = document.getElementById("tab_particle");
    const particle_page = document.getElementById("particle_page");
    
    // function set_general_page() {
    //     remove_all_selected();
    //     general_btn.setAttribute("selected", "")
    //     general_page.style.display = "flex";
    // }
    
    function set_filter_page() {
        remove_all_selected();
        filter_btn.setAttribute("selected", "")
        filter_page.style.display = "flex";
    }

    function set_particle_page() {
        remove_all_selected();
        particle_btn.setAttribute("selected", "")
        particle_page.style.display = "flex";
    }

    function remove_all_selected() {
        // general_btn.removeAttribute("selected");
        // general_page.style.display = "none";

        filter_btn.removeAttribute("selected");
        filter_page.style.display = "none";

        particle_btn.removeAttribute("selected");
        particle_page.style.display = "none";
    }


    // general_btn.addEventListener("click", () => set_general_page());

    filter_btn.addEventListener("click", () => set_filter_page());

    particle_btn.addEventListener("click", () => set_particle_page());

    set_particle_page();
})